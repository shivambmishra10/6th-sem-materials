// This is a simple Java program.
// FileName : "HelloWorld.java".

class helloworld
{
	// Your program begins with a call to main().
	// Prints "Hello, World" to the terminal window.
	public static void main(String args[])
	{
		System.out.println("my name is shivam how are you");
	}
}
