isa(a,b).


