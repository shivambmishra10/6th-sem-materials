input_name :-
   write('Whats ur name: '),
   read(Name),
   write('Hello '),write(Name) ,nl.

